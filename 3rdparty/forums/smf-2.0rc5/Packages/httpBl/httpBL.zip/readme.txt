[b]MOD httpBL v2.5.1
=============[/b]

[table][tr][td][+][b]Author:[/b][/td][td][b][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=68708]snoopy_virtual[/url][/b][/td][/tr]

[tr][td][+][b]Version:[/b][/td][td]2.5.1[/td][/tr]

[tr][td][+][b]Release:[/b][/td][td]28th December 2010[/td][/tr]

[tr][td][+][b]Languages:[/b][/td][td][img]http://www.simplemachines.org/site_images/lang/english.gif[/img] [img]http://www.simplemachines.org/site_images/lang/english_british.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish_latin.gif[/img][/td][/tr]

[tr][td][+][b]Compatible With:[/b][/td][td]SMF 1.1.1 - 1.1.12
SMF 2 RC2 - RC4[/td][/tr][/table]

[table][tr][td][o][url=http://custom.simplemachines.org/mods/index.php?mod=2155#changelog][color=green][b]Change Log[/b][/color][/url][/td]
[td][url=http://custom.simplemachines.org/mods/index.php?mod=2155#changelog][img]http://www.simplemachines.org/community/Themes/smsite/images/buttons/reply.gif[/img][/url][/td][/tr][/table]

[table][tr][td][o][url=http://custom.simplemachines.org/mods/index.php?mod=2155#roadmap][color=green][b]Road Map[/b][/color][/url][/td]
[td][url=http://custom.simplemachines.org/mods/index.php?mod=2155#roadmap][img]http://www.simplemachines.org/community/Themes/smsite/images/buttons/reply.gif[/img][/url][/td]
[td](Before you ask for a new feature or report a bug
check if it's already in the cue waiting to be done)[/td][/tr][/table]

[b]Features:[/b]

[list][li]This mod uses the http:BL API from [url=http://www.projecthoneypot.org/?rf=62759]Project Honey Pot[/url] to stop spammers from accesing your forum.[/li][/list]

[list][li]If you don't know how this mod works you can [url=http://custom.simplemachines.org/mods/index.php?mod=2155]find more info here[/url] and inside the [url=http://www.simplemachines.org/community/index.php?topic=366399.0]official mod's support thread[/url].[/li][/list]

[b]Installation:[/b]

[center][color=red][b]IMPORTANT:[/b][/color]
Before you install this mod I will recommend you
[url=http://www.snoopyvirtualstudio.com/tutoriales/index.php?estudio=httpBL_2;language=english][b]to read this TUTORIAL[/b][/url][/center]

This mod follows the SMF Modifications TOS. Please see the included [b]SMF Mod TOS Draft.doc[/b] file for more details.

==========================

[b]Caracteristicas:[/b]

[list][li]Este mod usa la http:BL API de [url=http://www.projecthoneypot.org/?rf=62759]Project Honey Pot[/url] para impedir que los spammers puedan acceder a vuestro foro.[/li][/list]

[list][li]Si no sabes como funciona este mod puedes [url=http://custom.simplemachines.org/mods/index.php?mod=2155]ver mas informacion aqui[/url], en el [url=http://www.simplemachines.org/community/index.php?topic=366399.0]hilo oficial de soporte del mod (en ingles)[/url] y en el [url=http://www.simplemachines.org/community/index.php?topic=414747.0]hilo de soporte del mod en nuestro idioma[/url].[/li][/list]

[b]Instalacion:[/b]

[center][color=red][b]IMPORTANTE:[/b][/color]
Antes de instalar este mod te recomendaria que
[url=http://www.snoopyvirtualstudio.com/tutoriales/index.php?estudio=httpBL_2][b]leyeras este TUTORIAL[/b][/url][/center]
