[b]MOD Stop Spammer v2.3.9
==================[/b]

[table][tr][td][table][tr][td][+][b]Authors:[/b][/td][td][b][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=148997]M-DVD[/url][/b] and [b][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=68708]snoopy_virtual[/url][/b][/td][/tr]

[tr][td][+][b]Version:[/b][/td][td]2.3.9[/td][/tr]

[tr][td][+][b]Release:[/b][/td][td]9th January 2010[/td][/tr]

[tr][td][+][b]Compatible With:[/b][/td][td]SMF 1.1.1 - 1.1.12
SMF 2 RC4[/td][/tr][/table][/td]

[td][table]

[tr][td]          [/td][td]          [/td][/tr]
[tr][td]          [/td][td]          [/td][/tr]
[tr][td]          [/td][td]          [/td][/tr]
[tr][td]          [/td][td][center][color=red][b]IMPORTANT:[/b][/color]
This MOD works better when used
together with [url=http://custom.simplemachines.org/mods/index.php?mod=2155][b]MOD httpBL[/b][/url][/center][/td][/tr]

[/table]
[/td][/tr][/table]

[table][tr][td][o][url=http://custom.simplemachines.org/mods/index.php?mod=1547#changelog][color=green][b]Change Log[/b][/color][/url][/td]
[td][url=http://custom.simplemachines.org/mods/index.php?mod=1547#changelog][img]http://www.simplemachines.org/community/Themes/smsite/images/buttons/reply.gif[/img][/url][/td][/tr][/table]

[table][tr][td][o][url=http://custom.simplemachines.org/mods/index.php?mod=1547#roadmap][color=green][b]Road Map[/b][/color][/url][/td]
[td][url=http://custom.simplemachines.org/mods/index.php?mod=1547#roadmap][img]http://www.simplemachines.org/community/Themes/smsite/images/buttons/reply.gif[/img][/url][/td]
[td](Before you ask for a new feature or report a bug
check if it's already in the cue waiting to be done)[/td][/tr][/table]

[table][tr][td][o][url=http://www.simplemachines.org/community/index.php?topic=283309.msg1920848#msg1920848][color=green][b]Read FAQ[/b][/color][/url][/td][/tr][/table]

[b]Features:[/b]

[list][li]If you don't know how this mod works you can [url=http://custom.simplemachines.org/mods/index.php?mod=1547]find more info here[/url] and inside the [url=http://www.simplemachines.org/community/index.php?topic=283309.0]official mod's support thread[/url].[/li][/list]

Thanks to 'Stop Forum Spam' for your DB and APIs.

Thanks to [url=http://www.simplemachines.org/community/index.php?action=profile;u=139580][b]WhatsTheRent[/b][/url] and [url=http://www.simplemachines.org/community/index.php?action=profile;u=130133][b]KahneFan[/b][/url] for idea.
 
==========================

[b]Caracteristicas:[/b]

[list][li]Si no sabes como funciona este mod puedes [url=http://custom.simplemachines.org/mods/index.php?mod=1547]ver mas informacion aqui[/url], en el [url=http://www.simplemachines.org/community/index.php?topic=283309.0]hilo oficial de soporte del mod (en ingles)[/url] y en el [url=http://www.simplemachines.org/community/index.php?topic=291588.0]hilo de soporte del mod en nuestro idioma[/url].[/li][/list]
