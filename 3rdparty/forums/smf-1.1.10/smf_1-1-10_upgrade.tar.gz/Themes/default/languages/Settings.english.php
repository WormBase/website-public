<?php
// Version: 1.1; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'The default theme from Simple Machines.<br /><br />Thanks go to Bloc and the design team.';

?>