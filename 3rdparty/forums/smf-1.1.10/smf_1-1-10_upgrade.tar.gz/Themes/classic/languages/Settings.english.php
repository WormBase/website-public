<?php
// Version: 1.1; Settings

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'The classic look that introduced the groundbreaking PHP/MySQL port of YaBB and distinguished it through two years of development until its rebirth as SMF.<br /><br />Author: <i><a href="mailto:webmaster@yabbse.org">The YaBB SE Team</a></i>.';

?>