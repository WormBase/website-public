[b]MOD Stop Spammer v2.3.7
==================[/b]

[table][tr][td][table][tr][td][+][b]Authors:[/b][/td][td][b][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=148997]M-DVD[/url][/b] and [b][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=68708]snoopy_virtual[/url][/b][/td][/tr]

[tr][td][+][b]Version:[/b][/td][td]2.3.7[/td][/tr]

[tr][td][+][b]Release:[/b][/td][td]7th February 2010[/td][/tr]

[tr][td][+][b]Languages:[/b][/td][td][img]http://www.simplemachines.org/site_images/lang/english.gif[/img] [img]http://www.simplemachines.org/site_images/lang/english_british.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/spanish_latin.gif[/img] [img]http://www.simplemachines.org/site_images/lang/arabic.gif[/img] [img]http://www.simplemachines.org/site_images/lang/french.gif[/img]
[img]http://www.simplemachines.org/site_images/lang/bulgarian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/portuguese_pt.gif[/img] [img]http://www.simplemachines.org/site_images/lang/portuguese_brazilian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/dutch.gif[/img] [img]http://www.simplemachines.org/site_images/lang/indonesian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/italian.gif[/img]
[img]http://www.simplemachines.org/site_images/lang/danish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/turkish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/russian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/ukrainian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/chinese-simplified.gif[/img] [img]http://www.simplemachines.org/site_images/lang/chinese-traditional.gif[/img]
[img]http://www.simplemachines.org/site_images/lang/swedish.gif[/img] [img]http://www.simplemachines.org/site_images/lang/indonesian.gif[/img] [img]http://www.simplemachines.org/site_images/lang/croatian.gif[/img] [/td][/tr]

[tr][td][+][b]Compatible With:[/b][/td][td]SMF 1.1.1 - 1.1.11
SMF 2 RC2[/td][/tr][/table][/td]

[td][table][tr][td][center][url=http://www.simplemachines.org/community/index.php?action=post;topic=283309.0][img]http://www.simplemachines.org/community/Themes/smsite/images/star.gif[/img][img]http://www.simplemachines.org/community/Themes/smsite/images/star.gif[/img][img]http://www.simplemachines.org/community/Themes/smsite/images/star.gif[/img][img]http://www.simplemachines.org/community/Themes/smsite/images/star.gif[/img][img]http://www.simplemachines.org/community/Themes/smsite/images/star.gif[/img][/url][/center][/td][td][url=http://www.simplemachines.org/community/index.php?action=post;topic=283309.0][b][color=blue]Comment this Mod[/color][/b][/url][/td][/tr]

[tr][td][center][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=148997][img]http://www.simplemachines.org/site_images/modtitlebar.png[/img][img]http://www.simplemachines.org/site_images/modtitlebar.png[/img][img]http://www.simplemachines.org/site_images/modtitlebar.png[/img][/url][/center][/td][td][url=http://custom.simplemachines.org/mods/index.php?action=profile;u=148997][b][color=red]M-DVD's MODs[/color][/b][/url][/td][/tr]

[tr][td][center][url=http://custom.simplemachines.org/mods/index.php?mod=1547][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/img.gif[/img][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/img.gif[/img][img]http://www.simplemachines.org/community/Themes/smsite/images/bbc/img.gif[/img][/url][/center][/td][td][url=http://custom.simplemachines.org/mods/index.php?mod=1547][b][color=orange]Images[/color][/b][/url][/td][/tr]

[tr][td][url=https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=4587421][img]https://www.paypal.com/en_GB/i/btn/btn_donate_SM.gif[/img][/url][/td][td][url=https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=4587421][color=green][b]Help support M-DVD's MODs[/b][/color][/url][/td][/tr]

[tr][td]          [/td][td]          [/td][/tr]
[tr][td]          [/td][td]          [/td][/tr]
[tr][td]          [/td][td]          [/td][/tr]
[tr][td]          [/td][td][center][color=red][b]IMPORTANT:[/b][/color]
This MOD works better when used
together with [url=http://www.snoopyvirtualstudio.com/tutoriales/index.php?estudio=httpbl]MOD httpBL[/url][/center][/td][/tr]

[/table]
[/td][/tr][/table]

[table][tr][td][o][iurl=#changelog][color=black][b]ChangeLog[/b][/color][/iurl][/td]
[td][iurl=#changelog][img]http://www.simplemachines.org/community/Themes/smsite/images/buttons/reply.gif[/img][/iurl][/td][/tr][/table]

[list][li][b][url=http://www.simplemachines.org/community/index.php?topic=283309.msg1920848#msg1920848][color=green]Read FAQ[/color][/url][/b][/li][/list]

[b]Features:[/b]

[list][li]With this MOD you can Block the Registry of Spammers in your Forum.[/li][/list]

[list][li]When registering a user, it will compare their data (nickname, IP and mail) with the "Stop Forum Spam" DB.
If it match any data, then the user is leaved inactive 'Waiting for Approval'.
[b]Admin > Members > Awaiting Approval[/b][/li][/list]

[list][li]You can leave the 'Inmediate Registration' enabled for all users (so you don't disturb them),
but if a Spammer is detected it will apply 'Register Approval' automatically.[/li][/list]

[list][li]Also you can check all data of many members (already registred) automatically with a simple click, selecting them in the list...
[b]Admin > Members > View All Members[/b][/li][/list]

[list][li]And report new Spammers and increase the DB, [b]with a simple click[/b].[/li][/list]

[list][li]It keeps a record of the number of all Spammers Blocked to date, you can enable and disable this MOD [url=http://www.simplemachines.org/community/index.php?topic=283309.msg1920848#msg1920848][b]and more[/b][/url][/li][/list]

Thanks to 'Stop Forum Spam' for your DB and APIs.

Thanks to [url=http://www.simplemachines.org/community/index.php?action=profile;u=139580][b]WhatsTheRent[/b][/url] and [url=http://www.simplemachines.org/community/index.php?action=profile;u=130133][b]KahneFan[/b][/url] for idea.
 
==========================

[table]
[tr][td]
[quote][color=blue][b]Languages (normal & utf-8)[/b][/color]
[list]
[+]English
[+]English_British
[+]Spanish_Es
[+]Spanish_Latin

[/list]

[list]
[*]Croatian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=189883][b]mbreber[/b][/url]

[/list]

[list]
[o]Arabic by [url=http://www.simplemachines.org/community/index.php?action=profile;u=126024][b]islam2hamy[/b][/url]
[o]French by [url=http://www.simplemachines.org/community/index.php?action=profile;u=202243][b]Gabatt[/b][/url]
[o]Bulgarian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=97075][b]6aro[/b][/url]
[o]Portuguese_Portugal by [url=http://www.simplemachines.org/community/index.php?action=profile;u=191980][b]candidosa2[/b][/url] & [url=http://www.simplemachines.org/community/index.php?action=profile;u=94593][b]FragaCampos[/b][/url]
[o]Portuguese_Brazilian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=191980][b]candidosa2[/b][/url] & [url=http://www.simplemachines.org/community/index.php?action=profile;u=94593][b]FragaCampos[/b][/url]
[o]Dutch by [url=http://www.simplemachines.org/community/index.php?action=profile;u=205504][b]Laurens73[/b][/url] & [url=http://www.simplemachines.org/community/index.php?action=profile;u=224951][b]boudie[/b][/url]
[o]Indonesian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=71820][b]Exsharaen[/b][/url]
[o]Italian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=88848][b]OriginalP[/b][/url]
[o]Danish by [url=http://www.simplemachines.org/community/index.php?action=profile;u=208073][b]zcuba[/b][/url]
[o]Turkish by [url=http://www.simplemachines.org/community/index.php?action=profile;u=71538][b]GaMeR[/b][/url]
[o]Russian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=135774][b]ZeUsSaN[/b][/url]
[o]Ukrainian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=135774][b]ZeUsSaN[/b][/url]
[o]Chinese Simplified by [url=http://www.simplemachines.org/community/index.php?action=profile;u=8089][b]fmben[/b][/url]
[o]Chinese Traditional by [url=http://www.simplemachines.org/community/index.php?action=profile;u=8089][b]fmben[/b][/url]
[o]Swedish by [url=http://www.simplemachines.org/community/index.php?action=profile;u=196436][b]JornB[/b][/url]
[o]Indonesian by [url=http://www.simplemachines.org/community/index.php?action=profile;u=219119][b]affbrow[/b][/url] & [url=http://www.simplemachines.org/community/index.php?action=profile;u=71820][b]Exsharaen[/b][/url]
[/list]
[/quote]
[/td]

[td]	[/td]

[td]
[quote][color=blue][b]Legend[/b][/color]
[list][+]Included in MOD package[/list]
[list][*]Included in language_full.zip and translation complete[/list]
[list][o]Included in language_full.zip but translation incomplete[/list]
[/quote]
[/td][/tr]
[/table]

[quote]
[php]$txt['stopspammer_error'] = 'Error with Anti SPAM DB. Connection Failed.<br />
Please try again later, or Contact with the WebMaster';
$txt['stopspammer_count'] = 'Spammers blocked up until today';
$txt['stopspammer_title'] = 'Search more info in `Stop Forum Spam`';

$txt['stopspammer_enable'] = 'Enable/Disable MOD Stop Spammer';
$txt['stopspammer_show01'] = 'Show Link "More Info" for All Members';
$txt['stopspammer_show01_sub'] = 'You can check any member at any time with one simple click';

$txt['stopspammer_faildb'] = 'If the Connection Fail with Anti SPAM DB...';
$txt['stopspammer_fail01'] = 'Show Error and Stop Registration';
$txt['stopspammer_fail02'] = 'Allow Immediate Registration';
$txt['stopspammer_fail03'] = 'Member Approval and show yellow icon to check later';
$txt['stopspammer_faildb1_sub'] = 'Your host can make remote connection with the DB';
$txt['stopspammer_faildb2_sub'] = 'Your host couldn\'t make connection with the DB. Try again later.<br />
If this error continues see Support Topic and search ';
$txt['stopspammer_not_translate'] = '<a href="http://www.simplemachines.org/community/index.php?topic=283309.new#post_issues"><span class="error"><b>Known Issues</b></span></a>';

$txt['stopspammer_leyd01'] = 'Not Spammer: This data wasn\'t in a DB. But you can check';
$txt['stopspammer_leyd02'] = 'Suspect: This member couldn\'t be checked. Check now';
$txt['stopspammer_leyd03'] = 'Spammer: See more info of activity of this spammer';

$txt['stopspammer_profilecheck'] = 'Check this member';
$txt['stopspammer_limitexceded'] = 'You have exceded the check limit (5000 API queries per day).<br />
You should wait until tomorrow to check again.';

$txt['in_stop_forum_spam'] = 'In Stop Forum Spam Web:';
$txt['spammers_checks'] = 'Check these Members';
$txt['spammers_report'] = 'Report these Members';
$txt['confirm_spammers_checks'] = 'Are you sure you want to check the selected members?';
$txt['confirm_spammers_report'] = 'Are you sure you want to report the selected members?\n\n
Think that when you report a member to SFS they are marked as spammer all over the world\n
and they won\\\'t be able to use any of the forums connected to SFS around the world.\n\n
Do it only if you are completely sure they are spammers and if by any chance you make a mistake\n
tell as soon as possible the mod\\\'s creator to correct the mistake inside the SFS database.';

$txt['stopspammer_api_key'] = 'Your API key';
$txt['stopspammer_api_key_sub'] = 'If you want to use your own API key you must go first to 
<a href="http://www.stopforumspam.com/signup" target="_blank">www.stopforumspam.com</a> to sign up for one 
and write it here. If you haven\'t got one just leave it blank and the mod will use the default API key.';

$txt['stopspammer_check_sub1'] = '<br />If MOD Stop Spammer is enabled, every time we check a member:';
$txt['stopspammer_check_name'] = 'Check their username';
$txt['stopspammer_check_mail'] = 'Check their email';
$txt['stopspammer_check_ip'] = 'Check their IP';
$txt['stopspammer_check_sub2'] = 'By default, every time you check a member with MOD Stop Spammer it will 
check their username, email and IP. If you are getting too many false positives because of their usernames 
you can turn that option off. We wouldn\'t recomend you to turn off the another 2 options (to check their 
email and IP) unless you know what you are doing.';[/php][/quote]

[url=http://www.simplemachines.org/community/index.php?action=post;topic=283309.0][color=navy][b]I welcome new translations here[/b][/color][/url]

==========================

[b]Caracter�sticas:[/b]

[list][li]Con este MOD tu puedes Bloquear el Registro de los Spammer en tu Foro[/li][/list]

[list][li]Al registrarse un Usuario se comparan sus datos (nick, IP y mail) con la DB de la web 'Stop Forum Spam' y si coincide alg�n dato, el usuario quedar� inactivo 'Esperando Aprobaci�n'.[/li][/list]

[list][li]Tu puedes tener el 'Registro Inmediato' activado para todos los usuarios (y no causarles molestias), pero a los Spammer que se detecten se les aplicar� 'Aprobaci�n del Registro'.[/li][/list]

[list][li]Tambi�n puedes revisar todos los datos de muchos miembros (que ya est�n registrados) autom�ticamente con un simple click, seleccion�ndolos en la lista.[/li][/list]

[list][li]Y tambi�n puedes reportar nuevos Spammers y aumentar la DB, [b]con un simple click[/b].[/li][/list]

[list][li]Tambi�n, lleva un registro num�rico de todos los Spammer bloqueados hasta la fecha, activar y desactivar el MOD [url=http://www.simplemachines.org/community/index.php?topic=283309.msg1920848#msg1920848][b]y M�s[/b][/url][/li][/list]

Fin.

==========================

[anchor=changelog][b]ChangeLog:[/b][/anchor]

[table]
[tr][td]
[quote][url=http://www.simplemachines.org/community/index.php?topic=283309.msg1859411#msg1859411][color=blue][b]Version 1.0[/b][/color][/url] - 31th December 2008
	o Initial release
	o Can Block the Registry of Spammer in your Forum
	o Will be checked their data (nickname, IP and mail) in SFS DB
	o If match any data, the user is inactive Waiting for Approval
	o You can set enabled the Inmediate Registration with this MOD
	o Also, it keeps a record number of all Spammers Blocked
	o Compatible with SMF 1.1.X & SMF 2b-RC
[url=http://www.simplemachines.org/community/index.php?topic=283309.msg1920829#msg1920829][color=blue][b]Version 2.0[/b][/color][/url] - 08th February 2009
	+ You can enable and disable this MOD with a click
	+ The MOD automatically test your host for conection remote
	+ You can choose the action if the connection fails
	+ Your user will have three states (blue, yellow & red)
	+ You can check any data in SFS Web, with a click
	+ You can check all data of many members with a click
	+ You can report many members with a simple click
	!  Fixed issue with membername and error in conection
	?  Unistall & Update. It's not necessary to re-edit the template files
[url=http://www.simplemachines.org/community/index.php?topic=283309.msg1920829#msg1920829][color=blue][b]Version 2.1[/b][/color][/url] - 08th February 2009
	!  Fixed typo bug in the function checkreportMembers
	?  Unistall & Update. It's not necessary to re-edit the template files
[url=http://www.simplemachines.org/community/index.php?topic=283309.msg1930572#msg1930572][color=blue][b]Version 2.2[/b][/color][/url] - 13th February 2009
	!  Fix issue in Registration from ACP
	?  Unistall & Update. It's not necessary to re-edit the template files
[url=http://www.simplemachines.org/community/index.php?topic=283309.msg2279605#msg2279605][color=blue][b]Version 2.3[/b][/color][/url] - 27th September 2009
	* Changes in the Code
	* Regex repaired (the API XML SFS's was changed)
	* If the member is approved is showed in blue
	+ You can go to check & report a member via his profile
	+ If the API limit query is exceded, you will be notified
	?  Unistall & Update. It's not necessary to re-edit the template files
[url=http://www.simplemachines.org/community/index.php?topic=283309.msg2494138#msg2494138][color=blue][b]Version 2.3.7[/b][/color][/url] - 7th February 2010
	* Changes in the Code to make the mod compatible with 1.1.11 and 2.0 RC2
	* Some minor changes in english language files
	+ You can use now your own API key if you want
	+ You can now decide if the mod will check or not the username, email and IP
	+ 7 new strings in language files
	!  Fixed the yellow bug
	!  Fixed issue with utf-8 spanish language files
	!  Fixed some minor bugs
	?  Unistall & Update. It's not necessary to re-edit the template files
       unless you have in your template folder the file
       ManageMembers.template.php or Register.template.php
[/quote]
[/td]

[td]
[quote][color=blue][b]Legend[/b][/color]
[table]
[tr][td][size=1]o[/size][/td][td][size=1]Feature[/size][/td][/tr]
[tr][td][size=1]*[/size][/td][td][size=1]Change[/size][/td][/tr]
[tr][td][size=1]+[/size][/td][td][size=1]Added[/size][/td][/tr]
[tr][td][size=1]-[/size][/td][td][size=1]Eliminated[/size][/td][/tr]
[tr][td][size=1]![/size][/td][td][size=1]Bug Fixed[/size][/td][/tr]
[tr][td][size=1]?[/size][/td][td][size=1]How to Update[/size][/td][/tr]
[/table]
[/quote]
[/td][/tr]
[/table]